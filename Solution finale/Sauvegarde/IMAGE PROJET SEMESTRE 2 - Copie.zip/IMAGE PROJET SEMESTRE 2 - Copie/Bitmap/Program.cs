﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace ProjetImage
{
    internal class Program
    {
        /// <summary>Background Color de la console : Gris par défaut, Noir si le mode nuit est activé</summary>
        private static ConsoleColor BGColor;
        /// <summary>Foreground Color de la console : Noir par défaut, Blanc si le mode nuit est activé</summary>
        public static ConsoleColor FGColor { get; private set; }


        private static readonly string ADRESSE_SAUVEGARDE =    //Insérer chemin jusqu'au dossier de sauvegarde contenant les fichiers
            Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Directory.GetCurrentDirectory()))) + "\\Sauvegardes\\";

        private static string ImageChargée = "Green";

        private static MyGraphics graph;
        private static MyImage image;

        private static InterpolationMode mode = InterpolationMode.Bicubique;

        private static bool KeepAspectRatio = false;

        private static Pixel PixelRemp = Pixel.FromColor(Couleurs.Noir_Clair);




        /// <summary>
        /// Méthode qui affiche un magnifique cadre contenant le mot "GAME" avec des fleurs. Peut être 'skip' par l'utilisateur en appuyant 
        /// sur n'importe quelle touche
        /// </summary>
        private static void Start()
        {
            Console.SetBufferSize(Console.WindowWidth + 10, 100);
            Console.SetWindowSize(Console.WindowWidth + 10, 49);
            Console.OutputEncoding = Encoding.Unicode;
            Console.CursorVisible = false;

            for (int i = 25; i < 31; i++)
            {
                for (int j = -6; j < 7; j++)
                {
                    Console.SetCursorPosition(Console.WindowWidth / 2 + i, Console.WindowHeight / 2 + j);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.Write(" ");
                }
            }
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Magenta;
            string TitleText = @"
                                                                                                    
                                                                                                    
                                          ___  _____ ______   ________  ________  _______        
                                          |\  \|\   _ \  _   \|\   __  \|\   ____\|\  ___ \       
                                          \ \  \ \  \\\__\ \  \ \  \|\  \ \  \___|\ \   __/|      
                                           \ \  \ \  \\|__| \  \ \   __  \ \  \  __\ \  \_|/__    
                                            \ \  \ \  \    \ \  \ \  \ \  \ \  \|\  \ \  \_|\ \   
                                             \ \__\ \__\    \ \__\ \__\ \__\ \_______\ \_______\  
                                              \|__|\|__|     \|__|\|__|\|__|\|_______|\|_______|  
                                                                                                  
                                                   Utilisez les flèches HAUT/BAS pour             
                                                   naviguer dans les différents menus             
                                                                                                
";
            Console.SetCursorPosition(Console.WindowWidth / 2 + 40, Console.WindowHeight / 2 - 7);
            Console.WriteLine(TitleText);
            for (int j = -10; j < 10; j++)
            {
                for (int k = 0; k < 33; k++)
                {
                    Console.SetCursorPosition(k, Console.WindowHeight / 2 + j);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Write(" ");
                }
            }
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            for (var i = 13; i > 0 && !Console.KeyAvailable; i--)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 30, Console.WindowHeight / 2 - 7 + i);
                Console.Write("|");
                System.Threading.Thread.Sleep(30);
            }
            for (int i = 30; i > -40 && !Console.KeyAvailable; i -= 2)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + i, Console.WindowHeight / 2 - 7);
                Console.Write((i == 30) ? "=" : "= ");
                System.Threading.Thread.Sleep(20);
            }
            for (var i = 0; i < 13 && !Console.KeyAvailable; i++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 - 38, Console.WindowHeight / 2 - 6 + i);
                Console.Write("|");
                System.Threading.Thread.Sleep(20);
            }
            Console.SetCursorPosition(Console.WindowWidth / 2 - 38, Console.WindowHeight / 2 + 7);
            for (int i = 0; i < 35 && !Console.KeyAvailable; i++)
            {
                Console.Write(i == 34 ? "=" : "= ");
                System.Threading.Thread.Sleep(20);
            }

            DateTime Attente = DateTime.Now.AddMilliseconds(900);
            while (TempsAttente(Attente) && !Console.KeyAvailable)
                continue;

            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetCursorPosition(Console.WindowWidth / 2 - 19, Console.WindowHeight / 2 + 6);


            BGColor = ConsoleColor.Gray;   //Initialisation des background et foreground colors
            FGColor = ConsoleColor.Black;


            string front = "Appuyez sur une ";
            string touche = "touche";
            Console.Write(front + touche + " pour continuer");

            Clignottement(touche, true, 130, Console.CursorTop, Console.WindowWidth / 2 - 19 + front.Length, touche.Length);

            CatchKey();

            Console.BackgroundColor = BGColor;
            Console.Clear();
        }


        private static void Main(string[] args)
        {
            MyImage bmp = new MyImage(ADRESSE_SAUVEGARDE + ImageChargée, MyImage.Extension.bmp);

            MyGraphics graph2 = new MyGraphics(bmp)
            {
                Quality = InterpolationMode.Bicubique,
                PixelRemplissage = Pixel.FromColor(Couleurs.Noir_Clair),
                KeepAspectRatio = false
            };
            //graph2.Redimensionnement(50.0);
            //graph2.Rotation(23.7);
            //new MyImageStatistiques(bmp, 300, 900).CreateHistogramme(HistogrammeMode.Echelle_Gris, true).Save(ADRESSE_SAUVEGARDE + nom + " (histogrammeCouleur4).bmp");
            //bmp.Save(ADRESSE_SAUVEGARDE + ImageChargée + " (rotation)", MyImage.Extension.bmp);

            
            Fractale julia = new Fractale(500, 500, Fractale.Types.Mandelbrot)
            {
                MaxItération = 200,
                CouleursHSL = true,
                Contraste = 3,
                TailleMosaique = 80,
            };
            julia.CreateFractale();
            julia.Save(ADRESSE_SAUVEGARDE + "FRACTALE TEST23.bmp");
            


            Console.SetBufferSize(Console.WindowWidth + 10, 5000);
            Console.SetWindowSize(Console.WindowWidth + 10, 49);
            Console.OutputEncoding = Encoding.UTF8;
            Start();
            bool exit = false;
            while (!exit)
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("(Appuyez sur les flèches HAUT/BAS pour naviguer dans le menu)\n");
                InitialisationMenu();
                switch (MenuDeroulant(MenuEtSousMenus))
                {
                    #region Menu 1

                    case M1 + 1:
                        retourMenuSameIndex = true;
                        indexMenu = M3;
                        m1Display = false;
                        m3Display = true;
                        break;

                    case M1 + 2:
                        retourMenuSameIndex = true;
                        indexMenu = M4 + 1;
                        m4Display = true;
                        break;

                    case M1 + 3:
                        retourMenuSameIndex = true;
                        ChangementOuvertures(true);
                        break;

                    case M1 + 4:
                        retourMenuSameIndex = true;
                        indexMenu = M1;
                        ChangementOuvertures(false);
                        break;

                    #endregion

                    #region Menu 2

                    case M2 + 1:
                        Console.WriteLine("Ecrire l'aggrandissement avec une ',' ");
                        double.TryParse(Console.ReadLine(), out double rapport);
                        graph.Redimensionnement(rapport);
                        break;

                    #endregion

                    #region Menu 3
                    #endregion

                    #region Menu 4

                    case M4 + 1:
                        retourMenuSameIndex = true;
                        indexMenu = M1 + 2;
                        m1Display = true;
                        break;

                    #endregion

                    #region Menu 5
                    #endregion

                    #region Param

                    case PARAM + 1: //Mode nuit
                        BGColor = BGColor == ConsoleColor.Black ? ConsoleColor.Gray : ConsoleColor.Black;
                        FGColor = FGColor == ConsoleColor.Black ? ConsoleColor.White : ConsoleColor.Black;
                        retourMenuSameIndex = true; //Retour menu
                        break;

                    case PARAM + 2: //Chargement image
                        List<string> NomFichier = Directory.GetFiles(ADRESSE_SAUVEGARDE).OfType<string>().ToList();
                        for (int i = 0; i < NomFichier.Count; i++)
                            NomFichier[i] = Path.GetFileName(NomFichier[i]);
                        NomFichier.Insert(0, $"Choisissez l'image à charger :");
                        ImageChargée = NomFichier[ChoixDeroulant(NomFichier, false, Console.CursorTop, 21, 1)];

                        InitialisationImage();
                        retourMenuSameIndex = true; //Retour menu
                        break;

                    case PARAM + 3: //Sauvegarde
                        Console.WriteLine("Ecrivez le nom du fichier à enregistrer");
                        image.Save(ADRESSE_SAUVEGARDE + Console.ReadLine());
                        break;

                    case PARAM + 4: //Type d'interpolation
                        List<string> interpo = Enum.GetNames(typeof(InterpolationMode)).ToList();
                        interpo.Insert(0, "Type d'interpolation ");
                        mode = (InterpolationMode)(ChoixDeroulant(interpo, false, Console.CursorTop, 3, 1) - 1);
                        retourMenuSameIndex = true; //Retour menu
                        graph.Quality = mode;
                        break;

                    case PARAM + 5: //Pixel de remplissage
                        int choix = ChoixDeroulant(new List<string> { "Comment choisisr le pixel ?", "Liste de couleur",
                            "Créer un pixel de toute pièce", "Annuler" }, true, Console.CursorTop, 3, 1);
                        if (choix == 1)
                        {
                            List<string> couleurs = Enum.GetNames(typeof(Couleurs)).ToList();
                            couleurs.Insert(0, "Choisissez une couleur ");
                            PixelRemp = Pixel.FromColor((Couleurs)(ChoixDeroulant(couleurs, false, Console.CursorTop, 11, 1) - 1));
                        }
                        else if (choix == 2)
                        {
                            Console.WriteLine("\nChoisissez les composantes du pixel, d'abord les centaines puis les dizaines puis les unités. Dans l'ordre R -> G -> B :\n");

                            string rC = Convert.ToString(NombresDeroulants(0, 2, "ROUGE : 000 | G : 0 | B : 0 | Choisissez le chiffre des CENTAINES : x00", 1, 1, 7, "", "00"));
                            int rCInt = Convert.ToInt32(rC);

                            string rD = Convert.ToString(NombresDeroulants(0, rCInt == 2 ? 5 : 9, $"ROUGE : {rC}00 | G : 0 | B : 0 | Choisissez le chiffre des DIZAINES : {rC}x0", 1, 1, 7, rC, "0"));
                            int rDInt = Convert.ToInt32(rD);

                            string rU = Convert.ToString(NombresDeroulants(0, rCInt == 2 && rDInt == 5 ? 5 : 9, $"ROUGE : {rC}{rD}0 | G : 0 | B : 0 | Choisissez le chiffre des UNITES : {rC}{rD}x", 1, 1, 7, rC + rD));
                            byte r = Convert.ToByte(rC + rD + rU);

                            Console.WriteLine("\nChoisissez la composante VERTE maintenant :\n");

                            string gC = Convert.ToString(NombresDeroulants(0, 2, $"r : {r} ||  VERT : 0  || b : 0 | Choisissez le chiffre des CENTAINES : x00", 1, 1, 7, "", "00"));
                            int gCInt = Convert.ToInt32(gC);

                            string gD = Convert.ToString(NombresDeroulants(0, gCInt == 2 ? 5 : 9, $"r : {r} ||  VERT : {gC}00  || B : 0 | Choisissez le chiffre des DISAINES : {gC}x0", 1, 2, 7, gC, "0"));
                            int gDInt = Convert.ToInt32(gD);

                            string gU = Convert.ToString(NombresDeroulants(0, gCInt == 2 && gDInt == 5 ? 5 : 9, $"r : {r} ||  VERT : {gC}{gD}0  || B : 0 | Choisissez le chiffre des UNITES : {gC}{gD}x", 1, 2, 7, gC + gD));
                            byte g = Convert.ToByte(gC + gD + gU);
                            
                            Console.WriteLine("\nChoisissez la composante BLEUE maintenant :\n");

                            string bC = Convert.ToString(NombresDeroulants(0, 2, $"r : {r} | g : {g} | BLEU : 0 | Choisissez le chiffre des CENTAINES : x00", 1, 1, 7, "", "00"));
                            int bCInt = Convert.ToInt32(bC);

                            string bD = Convert.ToString(NombresDeroulants(0, bCInt == 2 ? 5 : 9, $"r : {r} | g : {g} ||  BLEU : {bC}00  || Choisissez le chiffre des DISAINES : {bC}x0", 1, 2, 7, bC, "0"));
                            int bDInt = Convert.ToInt32(rD);

                            string bU = Convert.ToString(NombresDeroulants(0, bCInt == 2 && bDInt == 5 ? 5 : 9, $"r : {r} | g : {g} ||  BLEU : {bC}{bD}0  || Choisissez le chiffre des UNITES : {bC}{bD}x", 1, 2, 7, bC + bD));
                            byte b = Convert.ToByte(bC + bD + bU);

                            PixelRemp = new Pixel(r, g, b);

                            Console.WriteLine($"Votre pixel {PixelRemp} se rapproche de la couleur : " + Enum.GetName(typeof(Couleurs), Pixel.GetCouleur(PixelRemp)) + "\n");

                            Clignottement("Appuyez sur une touche...", true, 100, Console.CursorTop);
                            CatchKey();
                        }
                        retourMenuSameIndex = true; //Retour menu
                        graph.PixelRemplissage = PixelRemp;
                        break;

                    case PARAM + 6: //Respect du ratio
                        KeepAspectRatio = !KeepAspectRatio;
                        retourMenuSameIndex = true; //Retour menu
                        graph.KeepAspectRatio = KeepAspectRatio;
                        break;

                    #endregion

                    case Program.EXIT:
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Il n'y a rien à cet emplacement, veuillez choisir autre chose ...");
                        retourMenuSameIndex = true;
                        Thread.Sleep(2000);
                        break;
                }
            }
        }

        private static void InitialisationMenu()
        {
            MenuEtSousMenus[0] = "MENU PROGRAMMES\n" + (!IsNullOrEmpty(ImageChargée) ? "\n- Image Chargée " + ADRESSE_SAUVEGARDE + ImageChargée + "\n" : "");
            MenuEtSousMenus[PARAM + 1] = "  Mode Nuit : " + (BGColor == ConsoleColor.Black ? "\u221A " : "\u2573 ");
            MenuEtSousMenus[PARAM + 2] = "  Charger Image depuis : " + ADRESSE_SAUVEGARDE;
            MenuEtSousMenus[PARAM + 3] = "  Sauvegarder Image dans : " + ADRESSE_SAUVEGARDE;
            MenuEtSousMenus[PARAM + 4] = "  Type d'interpolation :  " + Enum.GetName(typeof(InterpolationMode), mode);
            MenuEtSousMenus[PARAM + 5] = "  Pixel de remplissage :  " + Enum.GetName(typeof(Couleurs), Pixel.GetCouleur(PixelRemp)) + "  " + PixelRemp.ToString();
            MenuEtSousMenus[PARAM + 6] = "  Conservation de l'aspect : " + (KeepAspectRatio ? "\u221A " : "\u2573 ");
        }

        private static void InitialisationImage()
        {
            image = new MyImage(ADRESSE_SAUVEGARDE + ImageChargée);
            graph = new MyGraphics(image);
            graph.Quality = mode;
            graph.KeepAspectRatio = KeepAspectRatio;
            graph.PixelRemplissage = PixelRemp;
        }


        #region Menu

        private static List<string> MenuEtSousMenus = new List<string>
                {
                    "MENU  PROGRAMMES\n",
                    "  Sous-Menu 1   ",  //1
                    "  Goto Sous-Menu 3  ",
                    "  Goto Sous-Menu 4 Index 1  ",
                    "  Ouverture de tous les sous-menus ",
                    "  Fermeture de tous les sous-menus  ",
                    FERMETURE_STRING,
                    "  Sous-Menu 2   ", //7
                    "  Aggrandir ou rétrécir l'image :  ",
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    FERMETURE_STRING,
                    "  Sous-Menu 3   ", //13
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    FERMETURE_STRING,
                    "  Sous-Menu 4   ", //18
                    "  Goto Sous-Menu 4 Index 2  ",
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    FERMETURE_STRING,
                    "  Sous-Menu 5   ", //24
                    "  Autre contenu à venir ...  ",
                    "  Autre contenu à venir ...  ",
                    FERMETURE_STRING,
                    "  Paramètres   ", //Fin - 8 = 28
                    "  Mode Nuit : ",
                    "  Charger Image :  ",
                    "  Enregistrer Image :  ",
                    "  Type d'interpolation :  ",
                    "  Pixel de remplissage :  ",
                    "  Conservation de l'aspect :  ",
                    FERMETURE_STRING,
                    "\nEXIT" //Fin = 36
                };

        private const string FERMETURE_STRING = " FERMER \n\n";

        private static int indexMenu = 0, indexSousMenu = 0, top = 0;

        private static bool retourMenuSameIndex = false, m1Display = false, m2Display = false, m3Display = false, m4Display = false, m5Display = false, paramDisplay = false;

        private const byte M1 = 1, M2 = 7, M3 = 13, M4 = 18, M5 = 24, EXIT = 36, PARAM = EXIT - 8;



        private static int MenuDeroulant(List<string> menuChoix)
        {
            ConsoleKeyInfo ckey;
            Console.Title = "Problème scientifique info    ||    Flèches HAUT/BAS pour naviguer dans le Menu | ENTREE pour choisir";
            Console.CursorVisible = false;

            if (!retourMenuSameIndex) //Si true, permet de garder en paramètre le choix de l'utilisateur si un jeu/exo n'existe pas, on peut aussi changer manuellement l'index donc la position dans le menu pour rediriger l'utilisateur
            {
                ChangementOuvertures(false);
                indexMenu = M1; //Initialisation index au sous-menu 1 lors du premier lancé
                indexSousMenu = 1;
                for (int i = 0; i < menuChoix.Count - 1; i++) //1er affichage des titres de sous-menu et du titre 
                {
                    if (IsSousMenuOrTitle(i))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write(menuChoix[i]);
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                        Console.WriteLine((i != 0) ? " (Appuyez sur ENTREE pour dérouler)\n\n" : "\n");
                    }
                    Console.ForegroundColor = FGColor;

                }
                top = Console.CursorTop;
                if (Console.CursorTop < Console.WindowHeight - 3)
                {
                    while (!Console.KeyAvailable) Clignottement(menuChoix[menuChoix.Count - 1], indexMenu == menuChoix.Count - 1, 100, top);
                    ckey = Console.ReadKey(true);
                    while (!Console.KeyAvailable && ckey.Key != ConsoleKey.UpArrow && ckey.Key != ConsoleKey.DownArrow) //Clignottement 
                    {
                        Clignottement(menuChoix[menuChoix.Count - 1], indexMenu == menuChoix.Count - 1, 100, top);
                        ckey = Console.ReadKey(true);
                    }
                }
                else //Si on atteint la hauteur max, on arrete le clignottement car on ne peut pas regarder le haut du menu sinon
                {
                    Clear(top, 0);
                    Console.WriteLine(menuChoix[menuChoix.Count - 1]);
                    ckey = Console.ReadKey(true);
                    while (ckey.Key != ConsoleKey.UpArrow && ckey.Key != ConsoleKey.DownArrow) ckey = Console.ReadKey();
                }
            }
            Console.BackgroundColor = BGColor;
            Console.Clear();

            bool premierLancer = true, fermetureSousMenu = false, alternanceColor = false;  //premierLancer = true ensuite tjrs false, estFermé = est-ce qu'on est sur une case 'Fermer', alternance = utile pour l'affichage quand on est sur une case 'Fermer'

            while (true) //Tant que l'utilisateur ne fait pas un choix valide, on reste dans la boucle menu
            {
                fermetureSousMenu = menuChoix[indexMenu] == FERMETURE_STRING; //Si on est sur un 'fermé' (=quand le sous-menu est déroulé, il y a une case 'FERMER' qui apparait, ce bool représente si l'utilisateur est dessus ou non)

                if (indexMenu < M2) indexSousMenu = M1;    //On détermine le num du sous-menu dans lequel on est, utile notamment pour l'affichage et le titre de la console
                else if (indexMenu < M3) indexSousMenu = M2;
                else if (indexMenu < M4) indexSousMenu = M3;
                else if (indexMenu < M5) indexSousMenu = M4;
                else if (indexMenu < PARAM) indexSousMenu = M5;
                else if (indexMenu < EXIT) indexSousMenu = PARAM;
                else indexSousMenu = EXIT;

                Console.Title = "Problème scientifique info    ||    Flèches HAUT/BAS pour naviguer dans le Menu | ENTREE pour choisir   ||   " +
                    menuChoix[indexSousMenu] + (menuChoix[indexMenu] == FERMETURE_STRING ? " , le refermer ?" : (indexMenu != M1 && indexMenu != M2 &&
                    indexMenu != M3 && indexMenu != M4 && indexMenu != M5 && indexMenu != PARAM && indexMenu != EXIT ? " -->" + menuChoix[indexMenu] : ""));

                for (int i = 0; i < menuChoix.Count - 1; i++) //Affichage
                {
                    if ((i > M1 && i < M2 && m1Display) || (i > M2 && i < M3 && m2Display) || (i > M3 && i < M4 && m3Display) || //Si ouverture de sous-menu, on déroule le sous-menu
                        (i > M4 && i < M5 && m4Display) || (i > M5 && i < PARAM && m5Display) || (i > PARAM && i < EXIT && paramDisplay) || IsSousMenuOrTitle(i))
                    {
                        if (i == indexMenu || (fermetureSousMenu && i == indexSousMenu)) //Si on est sur un index d'une fermeture, on met en surbrillance le sous-menu auquel correspond le 'fermé'
                        {
                            if (menuChoix[indexMenu] == FERMETURE_STRING || (i == indexSousMenu && fermetureSousMenu))
                            {
                                Console.BackgroundColor = ConsoleColor.Red;
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                if (menuChoix[i] == FERMETURE_STRING) Console.Write("\n -> ");
                                Console.Write(menuChoix[i]);
                            }
                            else
                            {
                                if (!IsSousMenuOrTitle(i)) Console.Write("\n -> ");
                                Console.BackgroundColor = ConsoleColor.DarkGreen;
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.Write(menuChoix[i]);
                            }
                        }
                        else if (menuChoix[i] == FERMETURE_STRING)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write(menuChoix[i]);
                        }
                        else if (!IsSousMenuOrTitle(i))
                        {
                            Console.BackgroundColor = (fermetureSousMenu && i < indexMenu && i > indexSousMenu) ? alternanceColor ? ConsoleColor.Yellow : ConsoleColor.Red : BGColor;
                            Console.Write(" ");
                            Console.BackgroundColor = BGColor;
                            Console.Write("- " + menuChoix[i]);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write(menuChoix[i]);
                        }
                        Console.BackgroundColor = BGColor;
                        Console.ForegroundColor = (i == indexMenu || (i == indexSousMenu && fermetureSousMenu)) ? (i == indexSousMenu && fermetureSousMenu) ? ConsoleColor.Green : FGColor : ConsoleColor.DarkGray;
                        if (IsSousMenuOrTitle(i) && i != 0)
                        {
                            if ((!m1Display && i == M1) || (!m2Display && i == M2) || (!m3Display && i == M3) ||  //Si pas d'ouverture de sous menu
                                (!m4Display && i == M4) || (!m5Display && i == M5) || (!paramDisplay && i == PARAM))
                                Console.Write(" (Appuyez sur ENTREE pour dérouler)\n");
                            else
                                Console.Write(" (Appuyez sur ENTREE pour enrouler)");
                        }
                        Console.BackgroundColor = (fermetureSousMenu && i < indexMenu && i >= indexSousMenu) ? (alternanceColor) ? ConsoleColor.Yellow : ConsoleColor.Red : BGColor;
                        if ((IsSousMenuOrTitle(i) || i == indexMenu) && menuChoix[i] != FERMETURE_STRING) Console.WriteLine("\n "); //On saute une ligne pour le titre du sous-menu et sur l'index auquel se situe l'utilisateur pour bien le mettre en évidence
                        else Console.WriteLine();
                        alternanceColor = !alternanceColor; //Alternance bckgrnd yellow et red
                        Console.BackgroundColor = fermetureSousMenu && i < indexMenu && i >= indexSousMenu ? alternanceColor ? ConsoleColor.Yellow : ConsoleColor.Red : BGColor;
                        if (!(IsSousMenuOrTitle(i) || i == indexMenu) && i == indexMenu - 1 && fermetureSousMenu) Console.Write(" ");
                        Console.ForegroundColor = FGColor;
                    } //Fin affichage
                }

                top = Console.CursorTop;
                if (premierLancer && Console.CursorTop >= Console.WindowHeight - 3)//Si on atteint la hauteur max, on arrete le clignottement car on ne peut pas regarder le haut du menu sinon
                {
                    Clear(top, 0);
                    Console.WriteLine(menuChoix[menuChoix.Count - 1]); //Exit 
                }

                while (!Console.KeyAvailable && Console.CursorTop < Console.WindowHeight - 3) //Clignottement 
                {
                    Clignottement(menuChoix[menuChoix.Count - 1], indexMenu == menuChoix.Count - 1, 100, top);
                }
                ckey = Console.ReadKey();

                if (ckey.Key == ConsoleKey.DownArrow || ckey.Key == ConsoleKey.S) //Bas
                {
                    if (indexMenu == M1 && !m1Display) indexMenu = M2; //Si pas d'ouverture de td déroulant, on saute l'index au sous-menu suivant
                    else if (indexMenu == M2 && !m2Display) indexMenu = M3;
                    else if (indexMenu == M3 && !m3Display) indexMenu = M4;
                    else if (indexMenu == M4 && !m4Display) indexMenu = M5;
                    else if (indexMenu == M5 && !m5Display) indexMenu = PARAM;
                    else if (indexMenu == PARAM && !paramDisplay) indexMenu = EXIT;
                    else if (indexMenu == menuChoix.Count - 1) indexMenu = 1; //Si tout en bas, on remonte au sous-menu 1
                    else indexMenu++; //Sinon si ouverture de sous-menu, on continue normalement
                }
                else if (ckey.Key == ConsoleKey.UpArrow || ckey.Key == ConsoleKey.Z) //Haut
                {
                    if (indexMenu == M2 && !m1Display) indexMenu = M1; //Si pas d'ouverture de sous-menu, on saute l'index au sous-menu précédent
                    else if (indexMenu == M3 && !m2Display) indexMenu = M2;
                    else if (indexMenu == M4 && !m3Display) indexMenu = M3;
                    else if (indexMenu == M5 && !m4Display) indexMenu = M4;
                    else if (indexMenu == PARAM && !m5Display) indexMenu = M5;
                    else if (indexMenu == EXIT && !paramDisplay) indexMenu = PARAM;
                    else if (indexMenu <= 1) indexMenu = menuChoix.Count - 1; //Si tout en haut, on descend au Exit
                    else indexMenu--; //Sinon si ouverture de sous-menu, on continue normalement
                }
                else if (ckey.Key == ConsoleKey.Enter) //Entrée
                {
                    if (menuChoix[indexMenu] == FERMETURE_STRING) //On ferme le td qui s'est déroulé si on est sur un 'fermé'
                    {
                        if (indexMenu < M2) indexMenu = M1;      //Comme on ferme le TD déroulé, on remet l'index sur l'index du sous-menu ouvert
                        else if (indexMenu < M3) indexMenu = M2;
                        else if (indexMenu < M4) indexMenu = M3;
                        else if (indexMenu < M5) indexMenu = M4;
                        else if (indexMenu < PARAM) indexMenu = M5;
                        else if (indexMenu < EXIT) indexMenu = PARAM;
                    }

                    if (indexMenu == M1) m1Display = !m1Display;
                    else if (indexMenu == M2) m2Display = !m2Display; //Inversion des bools, permets d'ouvrir/fermer les sous-menu
                    else if (indexMenu == M3) m3Display = !m3Display;
                    else if (indexMenu == M4) m4Display = !m4Display;
                    else if (indexMenu == M5) m5Display = !m5Display;
                    else if (indexMenu == PARAM) paramDisplay = !paramDisplay;
                    else break; //Si l'index n'est pas sur un sous-menu alors on est forcément sur un exercice/jeu (donc un choix valide), alors on break la boucle
                }

                Console.BackgroundColor = BGColor;
                Console.Clear();

                premierLancer = false;
            }
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(menuChoix[indexMenu] + "\n");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Title = "Problème scientifique info    ||    " + (indexSousMenu == M1 ? "Sous-menu 1" : indexSousMenu == M2 ? "Sous-menu 2" : indexSousMenu == M3 ? "Sous-menu 3" :
                indexSousMenu == M4 ? "Sous-menu 4" : indexSousMenu == M5 ? "Sous-menu 5" : indexSousMenu == PARAM ? "Paramètres" : "") + "  ==>" + menuChoix[indexMenu];
            Console.CursorVisible = true;
            retourMenuSameIndex = false;
            return indexMenu;
        }

        private static bool IsSousMenuOrTitle(int index)
        {
            return index == M1 || index == M2 || index == M3 || index == M4 || index == M5 || index == PARAM || index == 0;
        }

        private static void ChangementOuvertures(bool état)
        {
            m1Display = état;
            m2Display = état;
            m3Display = état;
            m4Display = état;
            m5Display = état;
            paramDisplay = état;
        }

        #endregion


        #region String déroulants

        /// <summary>
        /// Prend une <see cref="List{String}"/> en paramètre et renvoie un index correspondant au choix de l'utilisateur dans cette liste.
        /// </summary>
        /// <returns>Renvoie l'index du choix de l'utilisateur dans la liste principale</returns>
        private static int ChoixDeroulant(List<string> choix, bool b_clignottementAutorisé, int top, int maxAffichage, int indexAffichagePremierLancer)
        {
            Console.CursorVisible = false;

            if (choix == null || choix?.Count <= 1)  //On teste la liste
                return 0;

            //Ici on regarde les variables passées en paramètre et on les change si elles ne respectent pas certaines conditions, permet d'éviter des erreurs

            maxAffichage = (maxAffichage < choix.Count) ? maxAffichage <= 0 ? 5 : maxAffichage : choix.Count - 1; //maxAffichage = max d'item affichés >0 && <list.Count

            int indexList = maxAffichage == choix.Count - 1 ? 1 : indexAffichagePremierLancer < choix.Count - 1 && indexAffichagePremierLancer > 0 ? indexAffichagePremierLancer : 1,
                indexAffichage = indexAffichagePremierLancer == 1 ? 1 : (maxAffichage / 2) + (indexList > 0 ? 2 : 1),
                topClearCligno = 0; //index = l'index dans la liste 'choixAffichage', indexTab = l'index du premier élément de 'choixAffichage' dans la liste 'choix'


            bool premierLancer = true, b_clignottementEnCours = indexList == choix.Count - maxAffichage && b_clignottementAutorisé;

            List<string> choixAffichage = RefreshList(choix, indexList, indexAffichage, maxAffichage, true);  //La liste dont on affiche les éléments

            #region 1er affichage et 1er enregistrement d'une key

            //1er affichage sans interaction avec l'utilisateur
            for (int i = 0; i < (b_clignottementAutorisé ? choixAffichage.Count - 1 : choixAffichage.Count); i++)
            {
                if (i == 0) //Titre
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(choixAffichage[i] + "\n");
                }
                else //Autres choix, sans le choix du bas si le clignottement est activé
                {
                    Console.ForegroundColor = FGColor;
                    Console.WriteLine(" " + choixAffichage[i]);
                }
            }
            Console.WriteLine();

            topClearCligno = Console.CursorTop;

            if (b_clignottementEnCours) //Clignottement avant que l'utilisateur n'appuie sur une touche
            {
                Clignottement(choix[choix.Count - 1], indexAffichage == choixAffichage.Count - 1, 100, topClearCligno);
            }

            ConsoleKeyInfo ckey = Console.ReadKey(true);
            while (ckey.Key != ConsoleKey.DownArrow && ckey.Key != ConsoleKey.UpArrow && ckey.Key != ConsoleKey.Escape) //Clignottement tant que l'utilisateur n'appuie pas sur les flèches HAUT/BAS
            {
                if (b_clignottementEnCours) //Clignottement du dernier index de la liste
                {
                    Clignottement(choix[choix.Count - 1], indexAffichage == choixAffichage.Count - 1, 100, topClearCligno);
                }
                ckey = Console.ReadKey(true);
            }

            #endregion

            //Boucle principale, tant que l'utilisateur n'appuie pas sur entrée, on y reste
            while (ckey.Key != ConsoleKey.Enter)
            {
                choixAffichage = RefreshList(choix, indexList, indexAffichage, maxAffichage);
                Clear(top, 0);

                #region Affichage

                for (int i = 0; i < choixAffichage.Count + (b_clignottementEnCours ? -1 : 0); i++) //Affichage
                {
                    if (i == indexAffichage)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkGreen;
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"{(i == 1 ? "" : "\n")} {choixAffichage[i]} " +
                            $"{(i == choixAffichage.Count + (b_clignottementEnCours ? -2 : -1) ? "" : "\n")}");
                    }
                    else if (i == 0 || (indexList < choix.Count - maxAffichage && i == choixAffichage.Count - 1) || (indexList > 1 && i == 1))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(choixAffichage[i]);
                        if (i == 0) Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine(" " + choixAffichage[i]);
                    }
                    Console.BackgroundColor = BGColor;
                    Console.ForegroundColor = FGColor;
                    topClearCligno = Console.CursorTop;
                }

                #endregion

                #region Entrée utilisateur

                if (!premierLancer) //Pas d'entrée utilisateur la première fois car on l'a déjà fait avant d'entrer dans la boucle
                {
                    if (b_clignottementEnCours) //Clignottement 
                    {
                        Clignottement(choix[choix.Count - 1], indexAffichage == choixAffichage.Count - 1, 100, topClearCligno);
                    }
                    ckey = Console.ReadKey(true);
                }

                #endregion

                #region Flèche du Bas

                if ((ckey.Key == ConsoleKey.DownArrow || ckey.Key == ConsoleKey.S) && !premierLancer)
                {
                    if (indexList == choix.Count - maxAffichage) //Tout en bas
                    {
                        if (indexAffichage != maxAffichage + (indexList > 1 ? 1 : 0))
                            indexAffichage++; //On descend, l'index change
                        else  //On est tout en bas, on remonte tout en haut
                        {
                            indexList = 1;
                            indexAffichage = 1;
                        }
                    }
                    else if (indexList == 1)
                    {
                        if (indexAffichage < maxAffichage / 2 + 1) indexAffichage++;
                        else if (indexAffichage == maxAffichage / 2 + 1)
                        {
                            indexAffichage++;
                            indexList++;
                        }
                        else
                            indexList++;
                    }
                    else indexList++;  //On augmente l'index des éléments affichés, donne l'illusion de descendre
                }

                #endregion

                #region Flèche du haut

                if ((ckey.Key == ConsoleKey.UpArrow || ckey.Key == ConsoleKey.Z) && !premierLancer)
                {
                    if (indexList == 1) //Si on est en haut de la liste, alors son change l'index, sinon on change l'indexTab ce qui va changer la liste qui s'affiche
                    {
                        if (indexAffichage != 1)
                            indexAffichage--;
                        else
                        {
                            indexList = choix.Count - maxAffichage;
                            indexAffichage = maxAffichage + (indexList > 1 ? 1 : 0);
                        }
                    }
                    else if (indexList == 2)  //Problème ici, on est obligé d'ajuster manuellement à cause des 3 points qui indiquent que des éléments sont encore là
                    {
                        indexAffichage--;
                        indexList--;
                    }
                    else if (indexList == choix.Count - maxAffichage)
                    {
                        if (indexAffichage > maxAffichage / 2 + 2)
                            indexAffichage--;
                        else
                            indexList--;
                    }
                    else indexList--;   //On baisse l'index des éléments affichés, donne l'illusion de monter
                }

                #endregion

                #region Escape

                if (ckey.Key == ConsoleKey.Escape && b_clignottementAutorisé)
                {
                    indexList = choix.Count - maxAffichage;
                    indexAffichage = maxAffichage + (indexList > 1 ? 1 : 0);
                }

                #endregion

                b_clignottementEnCours = indexList == choix.Count - maxAffichage && b_clignottementAutorisé; //Si on est tout en bas, on clignotte
                premierLancer = false;
            }
            Clear(top, 0);

            #region Affichage Choix

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(choix[0] + " : ");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(choix[indexAffichage + indexList + (indexList > 1 ? -2 : -1)] + "\n");

            Console.ForegroundColor = FGColor;

            #endregion

            return indexAffichage + indexList - 1 + (indexList > 1 ? -1 : 0); // - 2 à cause de "..." et - 1 à cause du titre
        }


        /// <summary>
        /// Prends en paramètre 2 limites (<see cref="int"/>) et renvoie un nombre entre ces deux limites correspondant au choix de l'utilisateur
        /// </summary>
        private static int NombresDeroulants(int limMoins, int limPlus, string titreTop, int incrémentation, int indexAffichagePremierLancer, int maxAffichage = 7, string before = "", string after = "")
        {
            if (limMoins < limPlus && incrémentation < 0 ||
                limMoins > limPlus && incrémentation > 0 ||
                incrémentation == 0)
            {
                Console.WriteLine("Impossible de charger le menu déroulant, il y a une erreur dans les paramètres indiqués.");
                return 0;
            }

            List<string> nombres = new List<string>() { titreTop };
            for (int i = limMoins; i <= limPlus; i += incrémentation)   //On crée la List qui contient tous les nombres entre les limites
            {
                nombres.Add(before + i.ToString() + after);
            }
            int a = ChoixDeroulant(nombres, false, Console.CursorTop, maxAffichage, indexAffichagePremierLancer); //On parse le résultat 
            return limMoins + incrémentation * (a - 1); //On parse le résultat 
        }


        /// <summary>
        /// Renvoie la liste qui va être affichée dans la console
        /// </summary>
        private static List<string> RefreshList(List<string> choix, int indexList, int indexAffichage, int maxAffichage, bool premierLancer = false)
        {
            //Cette fonction gère la liste qui va etre affichée :
            //  - le nombre de char/string à afficher en fct de "maxAffichage"
            //  - l'affichage des '3 petits points' ou non pour signaler qu'il reste des char non affichés

            int choixIndex = indexAffichage + indexList + (indexList > 1 ? -2 : -1); //Index du choix de l'utilisateur, -1 et/ou -2 à cause du titre et/ou des 3 points                                  

            //On récup le choix sans les charact de controles (\n \r etConsole...)
            string choixAffichage = string.Empty;
            for (int i = 0; i < choix[choixIndex].Length; i++)
            {
                if (!char.IsControl(choix[choixIndex][i]))
                    choixAffichage += choix[choixIndex][i];
            }

            string titre = $"{choix[0]} : {(!premierLancer ? choixAffichage : "Appuyez sur les flèches HAUT/BAS")}";

            List<string> choixLimité = new List<string>() { titre };

            if (choix.Count > maxAffichage && indexList > 1) // Il y a un string pas affiché en haut, on rajoute des points pour le signaler
                choixLimité.Add(new string('\u0027', 3));

            for (int i = indexList; i < indexList + maxAffichage; i++)
                choixLimité.Add(choix[i]);

            if (choix.Count > maxAffichage && indexList < choix.Count - maxAffichage)
                choixLimité.Add("..."); // Il y a un string pas affiché en bas, on rajoute des points pour le signaler

            return choixLimité;
        }

        #endregion

        #region Fonctions utiles

        /// <summary>
        /// Clear la console en fonction de coordonnées indiquées par les paramètres.
        /// </summary>
        public static void Clear(int limiteHauteurClear, int limiteGaucheClear)
            => Clear(limiteHauteurClear, limiteGaucheClear, -1, -1);


        /// <summary>
        /// Clear la console en fonction de coordonnées indiquées par les paramètres. Initialiser limiteBas à -1 pour clear depuis le bas de la console.
        /// Initialiser limiteDroite en fonction de la distance par rapport à la limGauche et non le point le plus à gauche/droite de la console
        /// </summary>
        public static void Clear(int limiteHauteurClear, int limiteGaucheClear, int limiteBasClear, int longueurClearDroite)
        {
            limiteBasClear = limiteBasClear == -1 ? Console.CursorTop : limiteBasClear;
            longueurClearDroite = longueurClearDroite == -1 ? Console.WindowWidth : longueurClearDroite;

            if (limiteBasClear < limiteHauteurClear || longueurClearDroite <= 0) //Test
            {
                return;
            }

            for (int Ligne = limiteBasClear; Ligne >= limiteHauteurClear; Ligne--)  //On remplace toutes les lignes de la limite basse jusqu'à la limite haute 
            {                                                                       //et de la limite droite jusqu'à la limite gauche par des espaces.
                Console.SetCursorPosition(limiteGaucheClear, Ligne);
                Console.Write(new string(' ', longueurClearDroite));
            }
            Console.SetCursorPosition(limiteGaucheClear, limiteHauteurClear);
        }



        /// <summary>
        /// Fais clignotter un string dans la console, le fond de la console peut être fixé à rouge. La fonction supprime tous les 
        /// charactères entre le bas et limHauteurClear à chaque nouvel affichage du string coloré.
        /// </summary>
        private static void Clignottement(string toBlink, bool redBackground, int waitTimeColorMove, int limHauteurClear)
            => Clignottement(toBlink, redBackground, waitTimeColorMove, limHauteurClear, 0);


        /// <summary>
        /// Fais clignotter un string dans la console, background color can be set to red. La fonction supprime tous les charactères entre le bas et limHauteurClear
        /// et entre limGaucheClear (point par rapport au coté gauche de la console) et (limGaucheClear + limDroiteClear) à chaque nouvel affichage du string coloré. 
        /// </summary>
        private static void Clignottement(string toBlink, bool redBackground, int waitTimeColorMove, int limHauteurClear, int limGaucheClear, int limDroiteClear = -1)
        {
            var allColors = (ConsoleColor[])Enum.GetValues(typeof(ConsoleColor));
            var rand = new Random(Guid.NewGuid().GetHashCode());

            //String sans les char indésirables, on a juste besoin de la taille pour initialiser le tab de couleur
            int toBlinkRealLength = 0;
            for (int i = 0; i < toBlink.Length; i++)
                if (!char.IsControl(toBlink[i]) && !IsWhiteSpace(toBlink[i]))
                    toBlinkRealLength++;

            //On copie aléatoirement toutes les couleurs console dans un tab de la taille du stringReal à afficher
            ConsoleColor[] couleursPourAffichageString = new ConsoleColor[toBlinkRealLength];
            for (int index = 0; index < couleursPourAffichageString.Length; index++)
            {
                //Les couleurs claires sont situées à la fin de l'enum, on augmente leur chance d'être tirée quand le mode nuit est activé pour une meilleure visibilité
                int nbrng = rand.Next(allColors.Length);
                if (nbrng < 5 && BGColor == ConsoleColor.Black)
                {
                    nbrng = rand.Next(allColors.Length);
                    if (nbrng < 5)
                        nbrng = rand.Next(allColors.Length);
                }

                ConsoleColor couleurRNGToAddToArray = allColors[nbrng];
                while (couleurRNGToAddToArray == (redBackground ? ConsoleColor.Red : Console.BackgroundColor))
                {
                    couleurRNGToAddToArray = allColors[rand.Next(allColors.Length)];
                }
                couleursPourAffichageString[index] = couleurRNGToAddToArray;
            }

            //On affiche en couleur tant que l'utilisateur n'appuie pas sur une touche
            while (!Console.KeyAvailable)
            {
                //On décalle toutes les couleurs de 1 vers la droite
                ConsoleColor temp1CC = couleursPourAffichageString[0];
                ConsoleColor temp2CC = 0;
                for (int i = 0; i < couleursPourAffichageString.Length; i++)
                {
                    if (i < couleursPourAffichageString.Length - 1)
                    {
                        temp2CC = couleursPourAffichageString[i + 1];
                        couleursPourAffichageString[i + 1] = temp1CC;
                    }
                    else
                    {
                        couleursPourAffichageString[0] = temp1CC;
                    }
                    temp1CC = temp2CC;
                }


                Clear(limHauteurClear, limGaucheClear, -1, limDroiteClear);

                if (redBackground)
                    Console.BackgroundColor = ConsoleColor.Red;

                //Affichage
                for (int indexString = 0, indexColor = 0; indexString < toBlink.Length && indexColor < couleursPourAffichageString.Length; indexString++, indexColor++)
                {
                    while (indexString < toBlink.Length - 1 && (char.IsControl(toBlink[indexString]) || IsWhiteSpace(toBlink[indexString])))
                    {
                        Console.Write(toBlink[indexString++]);  //Saut des characteres indésirables (\n, espace, etc ...), on les ecrit mais on saute leur couleur
                    }

                    if (indexString >= toBlink.Length)
                        break;

                    Console.ForegroundColor = couleursPourAffichageString[indexColor];
                    Console.Write(toBlink[indexString]);    //Ecriture des charactères en couleur
                }
                Console.BackgroundColor = BGColor;

                System.Threading.Thread.Sleep(waitTimeColorMove);

            }

            Clear(limHauteurClear, limGaucheClear);
        }



        /// <summary>
        /// Affiche un <see cref="string"/> charactère par charactère. La fonction peut occasionnellement afficher un message clignottant à la fin pour signaler
        /// à l'utilisateur d'appuyer sur une touche pour continuer.
        /// </summary>
        private static void DisplayCharByChar(string phrase, bool clignottement, int timeBeforeEnd = 130)
        {
            Console.CursorVisible = true;
            Console.ForegroundColor = FGColor;

            for (int index = 0; index < phrase.Length; index++)
            {
                Console.Write(phrase[index]);
                if (!Console.KeyAvailable)              //Si l'utilisateur a appuyé sur une touche, on affiche le reste des lettres sans temps d'attente
                    System.Threading.Thread.Sleep(35);
            }


            if (Console.KeyAvailable)
            {
                CurseurClignottement();
                CatchKey();
            }
            else
            {
                System.Threading.Thread.Sleep(timeBeforeEnd);
            }

            Console.CursorVisible = false;
            Console.WriteLine();

            if (clignottement)
            {
                Clignottement("Appuyez sur une touche pour continuer", false, 100, Console.CursorTop);
            }
            else
            {
                CurseurClignottement();
            }

            Console.ForegroundColor = FGColor;
            Console.ReadKey(true);
            Console.CursorVisible = false;
        }



        /// <summary> On catch un appuie sur une touche de l'utilisateur, permet de ne pas interferer avec les autres ReadKey 
        /// qui prendraient en compte cette touche potentiellement indésirable</summary>
        private static void CatchKey()
        {
            if (Console.KeyAvailable)
                Console.ReadKey(true);
        }


        /// <summary>
        /// Fait clignotter le curseur de la console à interval régulier
        /// </summary>
        private static void CurseurClignottement()
        {
            while (!Console.KeyAvailable)  //Clignottement du curseur
            {
                Console.CursorVisible = true;
                System.Threading.Thread.Sleep(400);

                if (Console.KeyAvailable)  //On break entre les 2 temps d'attente pour pas avoir à attendre 400ms de plus si l'utilisateur appuie sur une touche
                    break;

                Console.CursorVisible = false;
                System.Threading.Thread.Sleep(400);
            }
        }


        /// <summary>
        /// Renvoie <see langword="true"/> si la date passée en paramètre est inférieure à <see cref="DateTime.Now"/>
        /// </summary>
        private static bool TempsAttente(DateTime Temps)
            => Temps > DateTime.Now;



        /// <summary>
        /// Renvoie <see langword="true"/> si le <see cref="char"/> passé en paramètre est une lettre de l'alphabet français (hors lettres spéciales). Renvoie <see langword="false"/> sinon
        /// </summary>
        public static bool IsLetter(char c)
        {
            return char.ToUpper(c) >= 'A' && char.ToUpper(c) <= 'Z';
        }


        /// <summary>
        /// Renvoie <see langword="true"/> si le <see cref="string"/> passé en paramètre est vide ou <see langword="null"/>. Renvoie <see langword="false"/> sinon
        /// </summary>
        public static bool IsNullOrEmpty(string s)
        {
            return s == null || s.Length <= 0;
        }


        /// <summary>
        /// Renvoie <see langword="true"/> si le <see cref="string"/> passé en paramètre est, <see langword="null"/> ou constitué uniquement d'espace blanConsole. Renvoie <see langword="false"/> sinon
        /// </summary>
        public static bool IsNullOrWhiteSpace(string s)
        {
            for (int index = 0; index < (s?.Length ?? 0); ++index)
            {
                if (!IsWhiteSpace(s[index]))
                    return false;
            }
            return true;
        }


        /// <summary>
        /// Renvoie <see langword="true"/> si le <see cref="char"/> passé en paramètre est un espace blanConsole. Renvoie <see langword="false"/> sinon
        /// </summary>
        private static bool IsWhiteSpace(char c)
        {
            return c == ' ';
        }


        #endregion

    }
}
