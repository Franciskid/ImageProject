﻿using System;

namespace ProjetImage
{
    /// <summary>
    /// Classe effectuant des opérations de filtrage sur des copies d'instances de <see cref="MyImage"/>
    /// </summary>
    internal class Filtre
    {
        //Champs et propriétés

        private MyImage matrixFiltrée;

        /// <summary>
        /// Addition du total des éléments dans la matrice de convolution de cette instance
        /// </summary>
        private int sommeTotale;

        /// <summary>
        /// Valeur ajoutée à chaque valeur de pixel lors du calcul matriciel
        /// </summary>
        private int correctif;

        /// <summary>
        /// Si <see langword="true"/>, le filtre est appliquée en 2 fois en divisant la matrice de convolution. Plus rapide. Pas implémenté
        /// </summary>
        private bool séparation;

        /// <summary>
        /// Récupère l'instance <see cref="MyImage"/> résultante du filtrage
        /// </summary>
        public MyImage GetMyImage => matrixFiltrée;
        

        private int GetTotal(float[][] convMat)
        {
            float value = 0;
            for (int i = 0; i < convMat.Length; i++)
            {
                for (int j = 0; j < convMat[i].Length; j++)
                {
                    value += convMat[i][j];
                }
            }
            if (value == 0) value = 1;
            return (int)value;
        }


        //Constructeurs

        /// <summary>
        /// Applique à une copie d'une instance <see cref="MyImage"/> le filtre <see cref="ConvolutionMatrix"/> spécifié
        /// </summary>
        /// <param name="bmp">Instance <see cref="MyImage"/> contenant les informations liées à l'image</param>
        /// <param name="convMat">Matrice de convolution</param>
        public Filtre(MyImage bmp, ConvolutionMatrix convMat)
            : this(bmp, convMat.GetMatrix(), convMat.Correctif, convMat.Séparation)
        {
        }

        /// <summary>
        /// Applique à une copie d'une instance <see cref="MyImage"/> le filtre spécifié
        /// </summary>
        /// <param name="bmp">Instance <see cref="MyImage"/> contenant les informations liées à l'image</param>
        /// <param name="convMat">Matrice de convolution</param>
        /// <param name="correctif">Valeur à ajouter à chaque pixel</param>
        /// <param name="séparation">Si <see langword="true"/>, le filtre est appliquée en 2 fois en divisant la matrice de convolution. Plus rapide.</param>
        public Filtre(MyImage bmp, float[][] convMat, int correctif = 0, bool séparation = false)
        {
            this.sommeTotale = GetTotal(convMat);
            this.correctif = correctif;
            this.séparation = séparation;

            this.matrixFiltrée = new MyImage(bmp.GetHeight, bmp.GetWidth);

            ApplicationFiltre(bmp, convMat);
        }


        //Méthodes de calculs

        /// <summary>
        /// Multiplie chaque pixel d'une matrice et les pixels autours de ce pixel par une matrice de convolution
        /// </summary>
        /// <param name="bmp"></param>
        /// <param name="convMatrix"></param>
        private void ApplicationFiltre(MyImage bmp, float[][] convMatrix)
        {
            for (int i = 0; i < bmp.GetHeight; i++)
            {
                for (int j = 0; j < bmp.GetWidth; j++)
                {
                    byte[] bgr = new byte[3];

                    for (int k = 0; k < 3; k++)
                    {
                        bgr[k] = GetValue(bmp, convMatrix, new int[2] { i, j }, k);
                    }

                    this.matrixFiltrée[i, j] = new Pixel(bgr);
                }
            }

        }

        private byte GetValue(MyImage bmp, float[][] convMatrix, int[] position, int couleur)
        {
            int autourIndex = convMatrix.Length / 2;  //Nombre de case à prendre en compte autour de la case position[], 1 si la mat est de taille 3, 2 si de taille 5

            int minY = position[0] - autourIndex;
            int minX = position[1] - autourIndex;

            int maxY = position[0] + autourIndex;
            int maxX = position[1] + autourIndex;

            double value = 0;

            for (int i = minY; i <= maxY; i++)
            {
                for (int j = minX; j <= maxX; j++)
                {
                    int x = j, y = i;

                    //On gère les contours en prenant les pixels miroirs à l'intérieur de l'image. 
                    //Par ex pour un pixel situé à 2 unités de distances en dehors de l'image on prendra le pixel à 2 unités à l'intérieur de l'image

                    if (x >= bmp.GetWidth)
                        x = bmp.GetWidth - 1 - (x - bmp.GetWidth);
                    else if (x < 0)
                    {
                        x = -x;
                    }
                    if (y >= bmp.GetHeight)
                        y = bmp.GetHeight - 1 - (y - bmp.GetHeight);
                    else if (y < 0)
                    {
                        y = -y;
                    }

                    byte color = couleur == 0 ? bmp[y, x].GetB : couleur == 1 ? bmp[y, x].GetG : bmp[y, x].GetR;

                    value += color * convMatrix[i - minY][j - minX];
                }
            }
            value = Math.Min(Math.Max(value / this.sommeTotale + this.correctif, 0), 255);

            return (byte)value;
        }

    }
}